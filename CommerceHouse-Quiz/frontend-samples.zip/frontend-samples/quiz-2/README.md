## INSTRUCTIONS

Create the lines of code needed below so that this script outputs the following text to the
browser's console (i.e. using console.log()):

```
Hello, my name is Harry!
Hello, my name is Ron!
Hello, my name is Hermione!
```