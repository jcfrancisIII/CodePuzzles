
# Commerce House Front-End Developer Quiz

Clone this repository and complete the 5 quizzes (located in each folder). Instructions for each of the questions are located in the README files in each folder.

When you have finished, submit a pull request (if you don't have a github account, you can send us a zip file).
