
## INSTRUCTIONS

Write a function that determines whether or not a sentence is a pangram (it contains every letter of the alphabet
at least once).

Write some test code that outputs the results (true or false) of the following sentences to the browser console (i.e. console.log):

- "The quick brown fox jumped over the lazy dog"
- "A wizard's job is to vex chumps quickly in fog"
- "Watch 'Jeopardy!', Alex Trebek's fun TV quiz game"
- "This is not a pangram"
